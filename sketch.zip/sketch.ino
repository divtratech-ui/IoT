#include <WiFi.h>
#include <PubSubClient.h>
#include <time.h>


const char* ssid = "Vercel-GUEST";
const char* password = "";


const char* mqtt_server = "mqtt-dashboard.com";


WiFiClient espClient;
PubSubClient client(espClient);


#define LED_PIN 2


const char* controlTopic = "home/led/control";
const char* statusTopic = "home/led/status";
const char* logTopic = "home/led/log";


bool ledState = false;

const char* ntpServer = "pool.ntp.org";
const long gmtOffset_sec = 3600;      // UTC+1
const int daylightOffset_sec = 0;

void publishStatus()
{
  if (ledState)
  {
    client.publish(statusTopic, "ON");
  }
  else
  {
    client.publish(statusTopic, "OFF");
  }
}

String getTimestamp()
{
    struct tm timeinfo;

    if (!getLocalTime(&timeinfo))
    {
        return "Unknown Time";
    }

    char buffer[30];

    strftime(
        buffer,
        sizeof(buffer),
        "%Y-%m-%d %H:%M:%S",
        &timeinfo
    );

    return String(buffer);
}

void callback(char* topic, byte* message, unsigned int length)
{
  String command = "";

  for(int i = 0; i < length; i++)
  {
    command += (char)message[i];
  }

  Serial.println(command);

  if(command == "ON" && !ledState)
  {
    digitalWrite(LED_PIN, HIGH);
    ledState = true;

    String log = getTimestamp() + " - LED turned ON";
    client.publish(logTopic, log.c_str());
  }

  if(command == "OFF" && ledState)
  {
    digitalWrite(LED_PIN, LOW);
    ledState = false;

    String log = getTimestamp() + " - LED turned OFF";
    client.publish(logTopic, log.c_str());
  }
}



void reconnect()
{
  while(!client.connected())
  {
    Serial.println("Connecting MQTT...");

    if(client.connect("ESP32_LED"))
    {
      Serial.println("MQTT connected");

      client.subscribe(controlTopic);

      publishStatus();

    }
    else
    {
      delay(2000);
    }
  }
}



void setup()
{
  Serial.begin(115200);


  pinMode(LED_PIN, OUTPUT);


  WiFi.begin(ssid,password);


  while(WiFi.status()!=WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }


  Serial.println("WiFi connected");


  client.setServer(mqtt_server,1883);
  client.setCallback(callback);
  configTime(
    gmtOffset_sec,
    daylightOffset_sec,
    ntpServer
  );

  Serial.println("Waiting for time...");

  struct tm timeinfo;

  while (!getLocalTime(&timeinfo)) {
    Serial.print(".");
    delay(500);
  }

  Serial.println();
  Serial.println("Time synchronized!");
}





void loop()
{
  if(!client.connected())
  {
    reconnect();
  }


  client.loop();
}